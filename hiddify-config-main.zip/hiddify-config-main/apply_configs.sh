#!/bin/bash
DO_NOT_INSTALL=true ./install.sh