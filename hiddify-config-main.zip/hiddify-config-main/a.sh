v=""
echo ${v:-unset}
