apt install -y netdata


