# Contributin

We are looking for contributors for this project. Please send email to hiddify@gmail.com


We need several type of helps:
- introducing our panel (we don't have any big media 😦)
- python developer
- rust developer (We do not want an high level rust developer. We just want to have someone who is familiar with rust and java script for a one day task)
- kotlin developer
- content providers
- services (for buying)

If you can help us, please dont hesitate to contact us at hiddify@gmail.com
