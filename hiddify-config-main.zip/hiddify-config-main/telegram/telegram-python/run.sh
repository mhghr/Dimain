systemctl enable mtproxy.service
systemctl restart mtproxy.service
