
apt install -y python3-pip
pip install bottle
pip3 install bottle



